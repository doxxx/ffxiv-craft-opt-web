## Required Information

Class:
Level:
Craftsmanship:
Control:
CP:
Recipe Name:
Recipe Level:
Solver Seed: (Look at the top of the Execution Log on the Solver page)

## Expected Behaviour

(Example: Standard Synthesis progress is 42)

## Actual Behaviour

(Example: Standard Synthesis progress is 38)

## Steps To Reproduce

(Example: Buffs, Food, Synthesis Condition, Simulator/Solver Options if different from default)
